java -jar ShoppingList.jar
